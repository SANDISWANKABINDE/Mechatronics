s = tf('s');
Transfer_eqn = (127.3*s+56.56)/(s^3 + 0.3392*s^2 +258.2*s+113.1);
rlocus(Transfer_eqn)
A = 1;
rlocus((s)*Transfer_eqn)
